"""Verify released files, reported summaries and raw-signal reconstruction (stdlib)."""
import bisect
import collections
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re
import zipfile
HERE = Path(__file__).resolve().parent


def verify_files():
    manifest = json.loads((HERE / 'checksums.json').read_text())
    for name, expected in manifest.items():
        assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, name
    observed = {str(p.relative_to(HERE)) for p in HERE.rglob('*')
                if p.is_file() and '__pycache__' not in p.parts and p.name != 'checksums.json'}
    assert observed == set(manifest), 'Unexpected or missing release files'
    pattern = re.compile(rb'(?:(?<!/)|(?<=://))/(?:home|Users|mnt|tmp|root|private|media)/|(?<![A-Za-z0-9+.-])[A-Za-z]:[\\/]')
    for name in manifest:
        path = HERE / name
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                assert archive.testzip() is None
                for member in archive.namelist():
                    assert not pattern.search(archive.read(member)), member
        elif path.suffix in {'.json', '.csv', '.py', '.md', '.world'}:
            assert not pattern.search(path.read_bytes()), name


def read_csv(relative):
    return list(csv.DictReader((HERE / relative).open()))


def percentile(values, fraction):
    values = sorted(values)
    q = (len(values)-1)*fraction
    i = int(q)
    return values[i] + (values[min(i+1,len(values)-1)]-values[i])*(q-i)


def verify_hover_windows():
    """Recompute all hover metrics from exported full-phase position samples."""
    import zipfile
    windows = read_csv('data/hover_analysis_windows.csv')
    signals = read_csv('data/hover_state.csv')
    groups = collections.defaultdict(list)
    for row in signals:
        groups[row['trial_id']].append(row)
    assert len(windows) == len(groups) == 21 and len(signals) == 12771
    assert set(groups) == {row['trial_id'] for row in windows}
    durations = []
    with zipfile.ZipFile(HERE/'data/configuration_records.zip') as archive:
        for window in windows:
            trial = window['trial_id']
            report = json.loads(archive.read(trial+'/report.json'))
            config = json.loads(archive.read(trial+'/resolved_case.json'))
            metrics = {item['name']: item for item in report['metrics']}
            start, end = float(window['analysis_start_s']), float(window['analysis_end_s'])
            assert config['run_options']['duration'] == float(window['configured_duration_s']) == 20
            assert report['analysis_phase'] == 'hover'
            assert abs(end-start-report['execution_duration']) < 1e-9
            assert abs(end-start-float(window['analysis_duration_s'])) < 1e-9
            durations.append(end-start)
            rows = groups[trial]
            assert len(rows) == int(window['state_samples'])
            assert all(start <= float(row['bag_time']) <= end for row in rows)
            positions = [[float(row[key]) for key in ('x','y','z')] for row in rows]
            target = [float(window[key]) for key in ('target_x','target_y','target_z')]
            assert target == metrics['position_bias']['detail']['reference']
            mean = [sum(p[axis] for p in positions)/len(positions) for axis in range(3)]
            bias = math.sqrt(sum((a-b)**2 for a,b in zip(mean,target)))
            jitter = math.sqrt(sum(sum((p[axis]-mean[axis])**2 for axis in range(3))
                                   for p in positions)/len(positions))
            for value, name, column in [(bias, 'position_bias', 'bias_m'),
                                         (jitter, 'position_jitter_rms', 'jitter_rms_m')]:
                assert abs(value-metrics[name]['value']) < 1e-10, (trial, name)
                assert abs(value-float(window[column])) < 1e-10, (trial, column)
    assert abs(min(durations)-20.268) < 1e-9 and abs(max(durations)-20.288) < 1e-9


def main():
    verify_hover_windows()
    from analyze_control_tracking import compute as figure3_compute
    from analyze_paired_trials import csv_text
    trial_metrics, group_medians = figure3_compute(HERE)
    assert len(trial_metrics) == 248 and len(group_medians) == 56
    assert (HERE/'data/control_tracking_trials.csv').read_text() == csv_text(trial_metrics)
    assert (HERE/'data/control_tracking_groups.csv').read_text() == csv_text(group_medians)
    svg = HERE/'assets/legacy_fig03_control_tracking.svg'
    if svg.exists():
        figure_text = svg.read_text()
        assert 'Median trial RMSE' in figure_text and 'Median trial P95' in figure_text
        assert 'Median position error' not in figure_text
    from analyze_tracking_selection import compute as compute_v15, table as table_v15
    selection_summary, selection_rows = compute_v15(HERE)
    assert (HERE/'data/tracking_selection_example.csv').read_text() == csv_text(selection_rows)
    assert json.loads((HERE/'data/tracking_selection_statistics.json').read_text()) == selection_summary
    assert [row['retained_trials'] for row in selection_rows] == [5,5,5,5,1,0]
    selection_table = HERE/'tables/tracking_selection.tex'
    if selection_table.exists():
        assert selection_table.read_text() == table_v15(selection_rows)
    from analyze_tracking_coverage import compute as compute_v16, table as table_v16
    coverage_rows, coverage_example = compute_v16(HERE)
    assert (HERE/'data/tracking_coverage_counts.csv').read_text() == csv_text(coverage_rows)
    combined_table = HERE/'tables/tracking_coverage.tex'
    if combined_table.exists():
        assert combined_table.read_text() == table_v16(coverage_rows,coverage_example)
    trials = read_csv('data/benchmark/trials.csv')
    online = [r for r in trials if r['task'] in ('sequential_goal_mission', 'reference_path_mission')]
    assert len(trials) == 566
    assert sum(r['included'] == 'True' for r in trials) == 561
    assert len(online) == 300
    assert sum(r['native_status'] == 'succeeded' for r in online) == 250
    assert sum(r['native_status'] == 'succeeded' and float(r['runtime_contact_count']) == 0 for r in online) == 198
    seq = [r for r in online if r['task'] == 'sequential_goal_mission']
    bad = [r for r in seq if r['native_status'] == 'succeeded' and r['geometry_1.0'] == 'False']
    assert len(bad) == 5 and sum(float(r['runtime_contact_count']) == 0 for r in bad) == 4
    assert collections.Counter(r['waypoint_count'] for r in seq) == {'1':172,'2':86}
    from summarize_planners import summarize
    expected_summary = [{key: str(value) for key, value in row.items()} for row in summarize()]
    assert read_csv('data/planner_summary.csv') == expected_summary
    quality = read_csv('data/controlled/trial_quality.csv')
    assert len(quality) == 80 and all(r['odom_geometry_1.0'] == r['world_truth_geometry_1.0'] == 'True' for r in quality)
    assert sum(float(r['runtime_contacts']) == 0 for r in quality) == 79
    assert all(r['runtime_contacts'] == r['replay_contacts'] for r in quality)
    combos = read_csv('data/online_combinations.csv')
    assert len(combos) == 300 and len({r['combination_id'] for r in combos}) == 50
    reversals = collections.Counter((r['odom_geometry_0.5'],r['world_truth_geometry_0.5'])
                                    for r in quality if r['odom_geometry_0.5'] != r['world_truth_geometry_0.5'])
    assert reversals == {('False','True'):4,('True','False'):1}
    signal = read_csv('data/worked_example/aligned_task.csv')
    # Independently reconstruct position support from exported raw points.
    expected = json.loads((HERE/'data/worked_example/readout.json').read_text())
    raw_points = read_csv('data/worked_example/reference_points.csv')
    windows = []
    for point in raw_points:
        if point['index'] == '0':
            windows.append({'received':float(point['bag_time']), 'points':[]})
        if int(point['valid_mask']) & 1:
            windows[-1]['points'].append((float(point['trajectory_start'])+float(point['time_from_start']), [float(point[k]) for k in ('x','y','z')]))
    windows = [w for w in windows if w['points']]
    for w in windows:
        w['points'].sort()
    receipt = [w['received'] for w in windows]
    reconstructed = []
    for row in read_csv('data/worked_example/state.csv'):
        t = float(row['bag_time'])
        if not expected['start'] <= t <= expected['end']:
            continue
        j = bisect.bisect_right(receipt, t)-1
        ref = None
        if j >= 0:
            points = windows[j]['points']
            if len(points) == 1:
                ref = points[0][1]
            elif points[0][0] <= t <= points[-1][0]:
                k = min(max(bisect.bisect_right([p[0] for p in points],t)-1,0),len(points)-2)
                left,right = points[k],points[k+1]
                ratio = (t-left[0])/(right[0]-left[0]) if right[0] != left[0] else 0
                ref = [a+ratio*(b-a) for a,b in zip(left[1],right[1])]
        if ref is not None:
            reconstructed.append(math.sqrt(sum((float(row[key])-ref[i])**2 for i,key in enumerate(('x','y','z')))))
    assert len(reconstructed) == 860
    assert abs(math.sqrt(sum(x*x for x in reconstructed)/len(reconstructed))-expected['rmse_m']) < 1e-10
    errors = []
    for row in signal:
        values = [float(row[k]) for k in ('x','y','z','ref_x','ref_y','ref_z')]
        if all(math.isfinite(v) for v in values):
            errors.append(math.sqrt(sum((values[i]-values[i+3])**2 for i in range(3))))
    assert len(signal) == 930 and len(errors) == 860
    assert abs(math.sqrt(sum(v*v for v in errors)/len(errors))-expected['rmse_m']) < 1e-10
    assert abs(percentile(errors,.95)-expected['p95_m']) < 1e-10
    assert min(float(r['goal_distance_m']) for r in signal) > 2
    assert len(read_csv('data/worked_example/contacts.csv')) == 2
    from analyze_paired_trials import compute, csv_text
    summary, conditions, differences, distributions = compute(HERE)
    assert json.loads((HERE/'data/paired_trial_statistics.json').read_text()) == summary
    assert summary['controlled']['conditional_bootstrap_95'] == [.025, .1125]
    assert summary['dynamic_package'] == dict(trials=100, native_success=81, with_contact=51, at_least_five_contacts=12)
    for filename, values in [('controlled_condition_counts', conditions), ('generator_pair_differences', differences),
                             ('generator_pair_summary', distributions)]:
        assert (HERE/'data'/(filename+'.csv')).read_text() == csv_text(values)
    # The new extraction must reproduce all eight previously reported medians.
    expected_medians = [-51.654, .899, .053, .214, -25.625, -.335, -.153, .089]
    assert [round(row['median'], 3) for row in distributions] == expected_medians
    from analyze_online_coverage import compute as compute_v11, tables as tables_v11
    new_summary, bins, thresholds, membership, by_controller = compute_v11(HERE)
    assert json.loads((HERE/'data/online_coverage_statistics.json').read_text()) == new_summary
    assert [row['trials'] for row in bins] == [10, 9, 35, 53, 193]
    assert [row['trials'] for row in thresholds] == [300, 290, 281, 246, 193]
    assert new_summary['online_total'] == dict(trials=300, native_success=250, with_contact=83,
        sequential_trials=258, sequential_geometric_complete=219, reference_path_trials=42)
    assert all(row['geometry_1m'] == 'N/A' for row in membership if row['task'] == 'reference_path_mission')
    for filename, values in [('online_coverage_bins', bins), ('online_coverage_thresholds', thresholds),
                             ('online_coverage_membership', membership), ('generator_controller_summary', by_controller)]:
        assert (HERE/'data'/(filename+'.csv')).read_text() == csv_text(values)
    for name, value in zip(('online_coverage', 'generator_controllers'), tables_v11(bins, thresholds, by_controller)):
        table_path = HERE/'tables'/(name+'.tex')
        if table_path.exists():
            assert table_path.read_text() == value
    from analyze_planner_composition import compute as compute_v12
    selection_summary, planner_selection = compute_v12(HERE)
    assert json.loads((HERE/'data/planner_composition_statistics.json').read_text()) == selection_summary
    assert (HERE/'data/online_coverage_by_planner.csv').read_text() == csv_text(planner_selection)
    excluded_0_9 = {row['planner']: row['excluded_trials'] for row in planner_selection if row['threshold'] == .9}
    assert excluded_0_9 == dict(airfar_planner=0, airfar_planner_mid360=0, ego_planner=3,
        ego_planner_mid360=2, ego_planner_v2=0, fast_planner_kino=10, fast_planner_topo=18, super_planner_od=21)
    for threshold in thresholds:
        selected = [row for row in planner_selection if row['threshold'] == threshold['threshold']]
        assert sum(row['original_trials'] for row in selected) == 300
        assert sum(row['retained_trials'] for row in selected) == threshold['trials']
    print('Verified 561 retained benchmark flights, 80 controlled flights, 68 generator pairs, '
          '300 online flights, conditional interval and independent raw-signal reconstruction.')


if __name__ == '__main__':
    verify_files()
    main()
