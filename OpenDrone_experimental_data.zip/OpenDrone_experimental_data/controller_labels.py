"""Controller abbreviations and presentation order shared by tables and figures."""

CONTROLLER_LABELS = [
    ('px4_position_baseline', 'PX4'),
    ('se3_hopf', 'Hopf'),
    ('se3_lee', 'Lee'),
    ('lqr_controller', 'LQR'),
    ('pid_controller', 'PID'),
    ('mav_linear_mpc', 'MPC'),
    ('mav_nonlinear_mpc', 'NMPC'),
]
