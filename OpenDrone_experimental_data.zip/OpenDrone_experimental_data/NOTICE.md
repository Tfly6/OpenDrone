# Licensing and source notices

The OpenDrone-authored experimental exports, analysis scripts and documentation
in this release use the repository's MIT license, reproduced in `LICENSE`.
The environment definitions below retain their source-specific licensing.

| Released files | Source and license notice |
| --- | --- |
| `data/environments/cylinders_85_45.world`, `cylinders_dynamic_40_30.world`, `forest.world` | Copied from OpenDrone `opendrone/sitl_config/worlds`; the component's GNU GPL version 3 text is retained in `licenses/GPL-3.0.txt`. These editable SDF files are included as source. |
| `data/environments/empty.world` | Copied unchanged from PX4's `Tools/simulation/gazebo-classic/sitl_gazebo-classic/worlds/empty.world`. The component's package metadata declares BSD; the accompanying PX4 BSD 3-Clause notice is retained in `licenses/PX4-BSD-3-Clause.txt`. |

Sources:

- OpenDrone: https://github.com/Tfly6/OpenDrone/tree/for_paper
- PX4 Gazebo Classic component: https://github.com/PX4/PX4-SITL_gazebo-classic
- PX4: https://github.com/PX4/PX4-Autopilot

The world files reference external Gazebo models, textures, materials and runtime
plugins. Those assets and binaries are not bundled in this data archive and retain
their own licenses. In particular, the OpenDrone `oak_tree_collision` model has
its own attribution file, identifying its derivation from the OSRF `oak_tree`
model under CC BY 3.0. Preserve that attribution when obtaining or redistributing
the model separately. See the environment-dependency section of `README.md`.
