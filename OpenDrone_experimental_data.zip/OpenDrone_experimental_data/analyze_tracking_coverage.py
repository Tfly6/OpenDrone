"""Generate the consolidated coverage-sensitivity table without changing its evidence."""
import csv
import hashlib
import json
from pathlib import Path
from analyze_paired_trials import csv_text
from analyze_tracking_selection import compute as example_compute, table as example_table
HERE=Path(__file__).resolve().parent


def compute(root=HERE):
    path=root/'data/benchmark/trials.csv'
    trials=list(csv.DictReader(path.open()))
    result=[]
    for task,label in [('analytic_circle','A-circle'),('analytic_figure8','A-figure-eight'),
                       ('analytic_spiral','A-spiral'),('discrete_circle','D-circle'),('discrete_figure8','D-figure-eight')]:
        values=[float(r['reference_coverage']) for r in trials if r['included']=='True' and r['task']==task]
        result.append(dict(task=task,label=label,trials=len(values),minimum_coverage=min(values),
                           coverage_0_80=sum(v>=.8 for v in values),coverage_0_90=sum(v>=.9 for v in values),
                           coverage_0_95=sum(v>=.95 for v in values)))
    assert [x['trials'] for x in result]==[34,34,35,70,67]
    assert [x['coverage_0_90'] for x in result]==[34,34,35,42,56]
    assert [x['coverage_0_95'] for x in result]==[31,33,35,35,34]
    _,example=example_compute(root)
    return result,example


def table(rows,example):
    text=r'''\papertable{\lang{归档控制器阶段覆盖率的敏感性分析。（a）解析（A）及生成（D）轨迹的试次数与达到门槛的数量。（b）LQR 圆轨迹保留试次数 $n$ 与逐试次 RMSE 中位数（m）；破折号表示无保留试次}{Sensitivity to archived controller-phase coverage. (a) Analytic (A) and generated (D) trials and counts meeting each threshold. (b) LQR circle retained trials $n$ and median per-trial RMSE (m); a dash denotes no retained trial}\label{tab:coverage}\label{tab:trackingselection}}
{\begin{tabular}{lrrrrr}\toprule
\multicolumn{6}{l}{\lang{(a) 任务类别}{(a) Task classes}}\\\midrule
\lang{任务}{Task} & $n$ & \lang{最低覆盖率}{Min. coverage} & $\geq .80$ & $\geq .90$ & $\geq .95$\\\midrule
'''
    translations={'A-circle':'A-圆','A-figure-eight':'A-八字','A-spiral':'A-螺旋','D-circle':'D-圆','D-figure-eight':'D-八字'}
    for r in rows:
        text+=r'\lang{'+translations[r['label']]+'}{'+r['label']+'}'+' & '+str(r['trials'])+f" & {r['minimum_coverage']:.3f}"+''.join(' & '+str(r[k]) for k in ('coverage_0_80','coverage_0_90','coverage_0_95'))+r'\\'+'\n'
    text+=r'''\bottomrule\end{tabular}\par\medskip
\begin{tabular}{lrrrrrr}\toprule
\multicolumn{7}{l}{\lang{(b) LQR 圆轨迹流水线}{(b) LQR circle pipelines}}\\\midrule
'''
    original=example_table(example)
    body=original.split(r'{\begin{tabular}{lrrrrrr}\toprule',1)[1]
    text+=body[:-2] if body.endswith('}\n') else body
    # Strip only the outer papertable body brace; retain the tabular end.
    return text+'}\n'


def main():
    rows,example=compute()
    (HERE/'data/tracking_coverage_counts.csv').write_text(csv_text(rows))
    if (HERE/'tables').is_dir():
        (HERE/'tables/tracking_coverage.tex').write_text(table(rows,example))
    print('Verified consolidated sensitivity table: all five task classes and both LQR pipelines.')


if __name__=='__main__':main()
