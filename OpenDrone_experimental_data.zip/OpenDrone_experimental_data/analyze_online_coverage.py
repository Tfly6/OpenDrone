"""Online coverage strata, threshold sensitivity and controller-specific pairs.

Read frozen records only; all calculations use the Python standard library.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
from controller_labels import CONTROLLER_LABELS as CONTROLLERS

from analyze_paired_trials import compute as previous_compute, csv_text, percentile, METRICS

HERE = Path(__file__).resolve().parent


def outcome_counts(rows):
    sequential = [row for row in rows if row['task'] == 'sequential_goal_mission']
    assert all(row['geometry_1.0'] in ('True', 'False') for row in sequential)
    return dict(trials=len(rows), native_success=sum(row['native_status'] == 'succeeded' for row in rows),
                with_contact=sum(float(row['runtime_contact_count']) > 0 for row in rows),
                sequential_trials=len(sequential),
                sequential_geometric_complete=sum(row['geometry_1.0'] == 'True' for row in sequential),
                reference_path_trials=len(rows) - len(sequential))


def compute(root=HERE):
    rows = list(csv.DictReader((root / 'data/benchmark/trials.csv').open()))
    online = [row for row in rows if row['task'] in ('sequential_goal_mission', 'reference_path_mission')]
    assert len(online) == 300
    assert all(math.isfinite(float(row['reference_coverage'])) and 0 <= float(row['reference_coverage']) <= 1 for row in online)
    edges = [0, .5, .8, .9, .95, 1]
    bins, membership = [], []
    for index, (low, high) in enumerate(zip(edges, edges[1:])):
        subset = [row for row in online if low <= float(row['reference_coverage'])
                  and (float(row['reference_coverage']) < high or index == 4 and float(row['reference_coverage']) == high)]
        interval = f'[{low:.2f},{high:.2f}' + (']' if index == 4 else ')')
        bins.append(dict(interval=interval, lower=low, upper=high, upper_inclusive=index == 4,
                         **outcome_counts(subset)))
        membership.extend(dict(trial_id=row['trial_id'], interval=interval,
                               reference_coverage=row['reference_coverage'], task=row['task'],
                               native_status=row['native_status'], runtime_contact_count=row['runtime_contact_count'],
                               geometry_1m=row['geometry_1.0'] if row['task'] == 'sequential_goal_mission' else 'N/A')
                          for row in sorted(subset, key=lambda row: row['trial_id']))
    assert len(membership) == len({row['trial_id'] for row in membership}) == 300
    thresholds = [dict(threshold=threshold, **outcome_counts(
        [row for row in online if float(row['reference_coverage']) >= threshold]))
                  for threshold in (0, .5, .8, .9, .95)]
    for field, total in outcome_counts(online).items():
        assert sum(row[field] for row in bins) == total

    _, _, pairs, _ = previous_compute(root)
    grouped = []
    for task in ('discrete_circle', 'discrete_figure8'):
        for controller, label in CONTROLLERS:
            selected = [row for row in pairs if row['task'] == task and row['controller'] == controller]
            assert len(selected) == (3 if controller == 'px4_position_baseline' and task == 'discrete_figure8' else 5)
            for metric in METRICS:
                values = [row[metric] for row in selected]
                grouped.append(dict(task=task, controller=controller, label=label, metric=metric,
                                    pairs=len(values), median=statistics.median(values),
                                    q1=percentile(values, .25), q3=percentile(values, .75),
                                    positive=sum(value > 0 for value in values), negative=sum(value < 0 for value in values)))
    by_controller = {}
    for task in ('discrete_circle', 'discrete_figure8'):
        medians = [row['median'] for row in grouped if row['task'] == task and row['metric'] == 'tracking_rmse_m']
        by_controller[task] = dict(controller_groups=len(medians), positive_medians=sum(value > 0 for value in medians),
                                   median_of_controller_medians=statistics.median(medians),
                                   minimum_controller_median=min(medians), maximum_controller_median=max(medians))
    summary = dict(online_total=outcome_counts(online),
                   coverage_field='reference_coverage (archived controller-phase sample fraction); replay coverage is separate',
                   bin_edges=edges, thresholds=[0, .5, .8, .9, .95],
                   below_0_9=sum(float(row['reference_coverage']) < .9 for row in online),
                   controller_tracking=by_controller,
                   input_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in (
                       'data/benchmark/trials.csv', 'data/configuration_records.zip')})
    return summary, bins, thresholds, membership, grouped


def tables(bins, thresholds, grouped):
    coverage = r'''\papertable{\lang{全部 300 次在线任务的归档控制器阶段参考覆盖率与结果。n 为试次数，N$+$ 为原生成功数，C1 为记录到接触的试次数；G$+$/seq. 为满足 1 m 有序访问规则的顺序任务数/该行顺序任务总数，Path 为参考路径任务数（几何判定不适用）。门槛仅用于跟踪比较的纳入选择}{Archived controller-phase reference coverage and outcomes for all 300 online trials. n: trials; N$+$: native successes; C1: trials with recorded contact; G$+$/seq.: 1 m visitation completions/sequential trials in that row; Path: reference-path trials (geometric decision N/A). Thresholds select tracking comparisons}\label{tab:onlinecoverage}}
{\begin{tabular}{lrrrrr}\toprule
\multicolumn{6}{l}{\lang{(a) 互不重叠的覆盖率区间}{(a) Disjoint reference-coverage intervals}}\\\midrule
\lang{覆盖率区间}{Coverage interval} & n & N$+$ & C1 & G$+$/seq. & Path\\\midrule
'''
    def numbers(row):
        return f"{row['trials']} & {row['native_success']} & {row['with_contact']} & {row['sequential_geometric_complete']}/{row['sequential_trials']} & {row['reference_path_trials']}"
    for row in bins:
        coverage += '{' + row['interval'] + '} & ' + numbers(row) + r'\\' + '\n'
    totals = {key: sum(row[key] for row in bins) for key in outcome_counts([])}
    coverage += r'\midrule ' + r'\lang{合计}{Total} & ' + numbers(totals) + r'\\\midrule' + '\n'
    coverage += r'''\multicolumn{6}{l}{\lang{(b) 嵌套门槛：达到最低覆盖率的试次}{(b) Nested thresholds: trials meeting minimum coverage}}\\\midrule
\lang{最低覆盖率}{Minimum coverage} & n & N$+$ & C1 & G$+$/seq. & Path\\\midrule
'''
    for row in thresholds:
        coverage += f"{row['threshold']:.2f} & " + numbers(row) + r'\\' + '\n'
    coverage += r'\bottomrule\end{tabular}}' + '\n'
    controllers = r'''\papertable{\lang{按固定控制器分组的 RPG 减 MAV 跟踪 RMSE 配对差值。各单元为中位数 [Q1, Q3]，单位为 m；n 为配对数。差值描述保留原生时间分配、约束和前馈字段的配置流水线}{Paired RPG-minus-MAV tracking-RMSE differences by fixed controller. Cells give median [Q1, Q3] in m; n is the number of pairs. Differences describe configured pipelines retaining native timing, constraints and feed-forward fields}\label{tab:controllerpairs}}
{\setlength{\tabcolsep}{4pt}\begin{tabular}{lrlrl}\toprule
\lang{控制器}{Controller} & n & \lang{圆：差值（m）}{Circle: difference (m)} & n & \lang{八字：差值（m）}{Figure-eight: difference (m)}\\\midrule
'''
    for controller, label in CONTROLLERS:
        values = []
        for task in ('discrete_circle', 'discrete_figure8'):
            row, = [row for row in grouped if row['task'] == task and row['controller'] == controller and row['metric'] == 'tracking_rmse_m']
            values.append(f"{row['pairs']} & {row['median']:.3f} [{row['q1']:.3f}, {row['q3']:.3f}]")
        controllers += label + ' & ' + ' & '.join(values) + r'\\' + '\n'
    controllers += r'\bottomrule\end{tabular}}' + '\n'
    return coverage, controllers


def main():
    summary, bins, thresholds, membership, grouped = compute()
    (HERE / 'data/online_coverage_statistics.json').write_text(json.dumps(summary, indent=2) + '\n')
    for filename, rows in [('online_coverage_bins', bins), ('online_coverage_thresholds', thresholds),
                           ('online_coverage_membership', membership), ('generator_controller_summary', grouped)]:
        (HERE / 'data' / (filename + '.csv')).write_text(csv_text(rows))
    if (HERE / 'tables').is_dir():
        for name, source in zip(('online_coverage', 'generator_controllers'), tables(bins, thresholds, grouped)):
            (HERE / 'tables' / (name + '.tex')).write_text(source)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
