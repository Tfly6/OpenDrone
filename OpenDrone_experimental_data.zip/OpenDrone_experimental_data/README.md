# OpenDrone experimental data

Experimental data for *OpenDrone: Measurement-Aware Cross-Level Evaluation of UAV Autonomy*.
The source code is in the [OpenDrone repository](https://github.com/Tfly6/OpenDrone/tree/for_paper).
This dataset is prepared for publication alongside the source code in the repository's `for_paper` branch.

## Contents

The dataset contains 566 benchmark attempts (561 retained flights) and 80 controlled flights, for 641 retained flights. The benchmark comprises 21 hover, 103 analytic-tracking, 137 generated-trajectory and 300 online flights. Five non-online attempts were excluded because the archived report identified insufficient position or explicitly timed-reference samples. Online timeouts and contact-limit terminations remain included.

| Path | Contents |
| --- | --- |
| `data/benchmark/trials.csv` | All 566 benchmark attempts, inclusion decisions, trial identifiers, reference coverage and native/geometric/contact outcomes |
| `data/benchmark/joint_outcomes.csv` | Task outcomes by planner, task group and visitation tolerance |
| `data/benchmark/coverage_sensitivity.csv` | Tracking summaries under minimum-reference-coverage selections |
| `data/controlled/trial_quality.csv` | All 80 controlled flights: source correspondence, observation windows, geometric labels and contact records |
| `data/configuration_records.zip` | Resolved configurations, parameter snapshots, run metadata and reports for all 646 attempts |
| `data/online_combinations.csv` | The 50 controller/planner/task combinations and their 300 online executions |
| `data/planner_summary.csv` | Eight planner/sensor configurations and their native, geometric and contact outcomes |
| `data/generator_pair_differences.csv` | The 68 task/controller/repeat-matched RPG-minus-MAV comparisons |
| `data/generator_pair_summary.csv` | Paired medians, quartiles and sign counts |
| `data/generator_controller_summary.csv` | Paired summaries within each fixed controller group |
| `data/hover_state.csv`, `data/hover_analysis_windows.csv` | All 12,771 full-phase hover position samples and per-trial window boundaries, configured/observed durations, target positions and bias/jitter readouts for the 21 hover flights |
| `data/control_tracking_trials.csv`, `data/control_tracking_groups.csv` | The controller trial metrics and group medians |
| `data/online_coverage_*.csv` | Online coverage intervals, thresholds, membership and planner composition |
| `data/tracking_*.csv` | Coverage-selection sensitivity of tracking estimates |
| `data/*_statistics.json`, `data/derived_statistics.json` | Reported statistical summaries and input checksums |
| `data/worked_example/` | State/reference/contact/progress signals, configuration, evaluation boundaries and computed readout for the Fast-kino/PID example |
| `data/environments/` | Gazebo world definitions used in the simulation study |
| `provenance.json`, `checksums.json` | Dataset scope, portable-path conventions and SHA-256 checksums |

Paths in this README are relative to the extracted archive root. Historical batch and trial identifiers are retained so that records can be joined across files; these identifiers are not publication version numbers. The full rosbag corpus is not included. The supplied CSV exports and configuration/report records support the reproduction commands below.

## License and attribution

OpenDrone-authored data exports, analysis scripts and documentation are provided
under the MIT license in `LICENSE`. Environment files retain their source-specific
licenses; see `NOTICE.md` and `licenses/` for the scope, source locations and
retained license texts. External simulation assets retain their own licenses.
When using this dataset in research, please cite the accompanying OpenDrone paper
and identify the repository commit used.

## Environment dependencies

The files in `data/environments/` are Gazebo Classic world definitions. Running
these worlds requires the OpenDrone simulation setup and the referenced model,
material and plugin resources; the archive is sufficient for the offline analysis
commands below, but does not bundle a simulation installation.

| World | Referenced resources |
| --- | --- |
| `empty.world` | Gazebo `sun` and `ground_plane`, and PX4's `asphalt_plane` model |
| `cylinders_85_45.world`, `cylinders_dynamic_40_30.world` | Gazebo material scripts; use the repository's launch configuration and plugins for simulation, including dynamic-obstacle motion |
| `forest.world` | `oak_tree`, `pine_tree`, `vrc_driving_terrain`, and OpenDrone's `oak_tree_collision`, including their meshes, textures and material scripts |

Use the resources and launch configuration in the linked OpenDrone repository's
`opendrone/sitl_config` component and its PX4/Gazebo dependencies. Gazebo must be
able to resolve their model, resource and plugin paths. The collision-tree source
and attribution are recorded in
`opendrone/sitl_config/models/oak_tree_collision/ATTRIBUTION.md`.

## Reproduce and verify

Python 3.8 or later is sufficient; the verification and analysis scripts use only the standard library. Run these commands from the extracted archive directory:

```bash
python3 verify_data.py
```

The verifier checks file integrity, the benchmark and controlled-flight denominators, online outcome intersections, paired-generator distributions, coverage sensitivity, the fixed-design conditional interval and raw-reference reconstruction for the worked flight. It also inspects every record inside the configuration ZIP for local machine paths.

To regenerate individual summaries:

```bash
python3 summarize_planners.py
python3 analyze_paired_trials.py
python3 analyze_online_coverage.py
python3 analyze_planner_composition.py
python3 analyze_tracking_selection.py
python3 analyze_tracking_coverage.py
python3 analyze_control_tracking.py
python3 verify_data.py
```

## Measurement conventions

Positions use ENU with the declared world/map identity. Common-frame correspondence between measured and reference positions is an input precondition for tracking: the archived tracking evaluator checks temporal correspondence and finite values, but does not compare frame IDs per sample or transform positions between frames. Geometric visitation checks frame validity separately. No fitted spatial registration is applied between raw odometry and simulator state. Their positions are matched by nearest header time within 50 ms in the controlled study; geometric visitation is evaluated independently on each raw sequence. The raw discrepancy includes coordinate-origin, reference-point, estimation and sampling-time effects.

Hover regulation uses the complete recorded hover phase after takeoff. All 21 configurations specify 20 s; the observed phases span 20.268–20.288 s. The exported `hover_state.csv` contains every position sample in these phases, with boundaries and targets in `hover_analysis_windows.csv`. `verify_data.py` independently recomputes bias and fluctuation RMS from these samples and checks all 21 archived reports. The plotted hover metrics use these full phases.

Tracking evaluation uses the recorded interface reference as the common motion demand; controllers retain their own reference-selection and buffering logic. A reference update contains the position-valid points in a recorded message; messages without such points do not replace the active reference. Reconstruction selects the latest reference update received at each recorded state time. A one-point update is held until the next reference update. Multi-point updates are interpolated only within their declared time support; samples outside that support remain unsupported, without fallback to earlier updates. Reference coverage measures interface-reference availability under this rule; a controller may continue executing a retained target during unsupported intervals. Position validity is bit 1 of `valid_mask`. The reconstructed-grid time check uses `max(1e-6, 1e-3 * median(positive state-time increments))` seconds and is separate from raw-stream matching.

Reference coverage and position retention are sample fractions. RMSE and P95 use eligible position samples; group summaries are medians of per-trial metrics, not errors pooled across flights. Coverage thresholds of 0.80, 0.90 and 0.95 select tracking summaries and do not change the full mission denominator.

The controller-active observation interval can include stopping. The bounded task window ends at the first matching, count-consistent native terminal or runner execution boundary and excludes later stopping, landing and artifact capture. The joint-outcome table evaluates geometric visitation in the bounded task window and contact counts in the runtime execution interval. Obstacle contacts exclude self/ground contact and use a 0.5 s recorder silence interval. Runtime and replay episode counts are retained separately where applicable.

| Signal | Clock and purpose |
| --- | --- |
| `/mavros/local_position/odom` | Recording time for benchmark tracking/visitation; header time for controlled raw-source matching |
| `/planner/output` | Receipt time selects the active message; trajectory start plus relative point time defines support |
| `/planner/mission_state` | Planner-owned progress and terminal state |
| `/flight_eval/contact_pulse` | Contact events; runtime and replay use their declared clocks |
| `/flight_eval/ground_truth/odom` | Simulator-state response stamp |
| `/flight_eval/ground_truth/query_duration` | Simulator service-query duration |

For 258 sequential-goal missions, geometric completion is ordered sampled 3D visitation at the declared tolerance, with zero dwell time and no interpolation across gaps. The 42 reference-path missions retain native/contact outcomes; point-goal completion is N/A for full-path fulfillment. Unknown geometry is distinct from failure.

The controlled design fixes two maps, two planners (EGO and Fast-kino), two controllers (Hopf and PID) and two tasks, with five repeats in each of 16 cells. The tasks are `(12, 8, 3)` m and `(8, 4, 3) -> (12, 8, 3)` m. Depth sensing and the 120 s budget are fixed. The 5/80 source-related geometric-label differences at 0.5 m give a conditional stratified empirical-bootstrap interval of 2.50–11.25%. The computation resamples paired-source trials within each fixed cell and computes the resulting binary distribution exactly. It describes repeat variation at the tested settings; zero-event cells remain zero under empirical resampling.

Generator differences compare complete configured pipelines with native time allocation, constraints and consumed feed-forward fields. Circle has 35 matched pairs and figure-eight has 33. These differences do not isolate the generator algorithm.

## Worked flight

The worked example is the dynamic-cylinder Fast-kino/PID trial `048_sequential_goal_mission1_pid_controller_fast_planner_kino_r02` with goal `(12.3, 12, 3)` m.

1. Restrict `state.csv` to `[2201.035, 2232.010]` s: 930 states.
2. Reconstruct the latest active reference from `reference_points.csv`: 860 supported error pairs.
3. Compute position RMSE `1.7345631772` m, P95 `3.7957162548` m and reference coverage `860/930`.
4. Native success occurs at `2232.010` s, but the minimum goal distance is `3.8032491089` m and the final distance is `6.4546877230` m.
5. Recorded contacts occur at `2223.609` and `2227.675` s.

`verify_data.py` reconstructs the reference directly from state and reference-point exports; `aligned_task.csv` and `readout.json` provide independent cross-checks.

## Portable paths and integrity

Local machine directories have been replaced by portable references in the published configuration records. `eval_runs/` denotes historical trial identifiers within the configuration ZIP; `src/OpenDrone/` refers to repository code; `external/` denotes dependencies not bundled here; and `runtime/` denotes historical temporary runtime locations. ROS topic and parameter names beginning with `/` and non-local resource and connection URIs remain unchanged. These JSON records describe the executed configurations; they are not installation scripts.

Experimental numeric and boolean values are preserved during export. SHA-256 values for sanitized report/configuration files are recalculated. In the benchmark trial table, `archived_report_sha256` and `archived_resolved_case_sha256` retain the corresponding original digests, while `report_sha256` and `resolved_case_sha256` identify the portable records in this archive. `checksums.json` identifies the released files, and `provenance.json` records the original and public configuration-archive digests. The archived digests preserve traceability to the original records.
