"""Report planner composition under archived coverage thresholds; no new flights."""
import csv
import hashlib
import json
from pathlib import Path

from analyze_paired_trials import csv_text

HERE = Path(__file__).resolve().parent


def compute(root=HERE):
    rows = list(csv.DictReader((root / 'data/benchmark/trials.csv').open()))
    online = [row for row in rows if row['task'] in ('sequential_goal_mission', 'reference_path_mission')]
    assert len(online) == 300
    result = []
    for threshold in (0, .5, .8, .9, .95):
        for planner in sorted({row['planner'] for row in online}):
            group = [row for row in online if row['planner'] == planner]
            kept = sum(float(row['reference_coverage']) >= threshold for row in group)
            result.append(dict(threshold=threshold, planner=planner, original_trials=len(group),
                               retained_trials=kept, excluded_trials=len(group) - kept,
                               retained_fraction=kept / len(group)))
    at_0_9 = [row for row in result if row['threshold'] == .9]
    assert sum(row['original_trials'] for row in at_0_9) == 300
    assert sum(row['excluded_trials'] for row in at_0_9) == 54
    summary = dict(coverage_field='reference_coverage: archived controller-phase sample fraction, possibly including stopping',
                   analysis_choice='Thresholds select tracking summaries; the mission denominator remains 300.',
                   at_0_9=at_0_9,
                   input_sha256=hashlib.sha256((root / 'data/benchmark/trials.csv').read_bytes()).hexdigest())
    return summary, result


def main():
    summary, result = compute()
    (HERE / 'data/online_coverage_by_planner.csv').write_text(csv_text(result))
    (HERE / 'data/planner_composition_statistics.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
