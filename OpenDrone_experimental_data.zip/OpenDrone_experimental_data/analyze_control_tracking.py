"""Rebuild the regulation/tracking figure from hash-checked archived reports.

Data extraction needs only the standard library. Plotting additionally uses
Matplotlib and NumPy; no external figure directory or ROS installation is used.
"""
import argparse
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import zipfile

from analyze_paired_trials import csv_text
from controller_labels import CONTROLLER_LABELS

HERE = Path(__file__).resolve().parent
CONTROLLERS = [key for key, _ in CONTROLLER_LABELS]
LABELS = [label for _, label in CONTROLLER_LABELS]
TASKS = ['analytic_circle', 'analytic_figure8', 'analytic_spiral']
HOVER_METRICS = ['position_bias', 'position_jitter_rms']
TRACKING_METRICS = ['position_tracking_rmse_3d', 'position_tracking_p95_3d']


def compute(root=HERE):
    trials = list(csv.DictReader((root / 'data/benchmark/trials.csv').open()))
    selected = [row for row in trials if row['included'] == 'True'
                and row['task'] in ['hover'] + TASKS]
    assert collections.Counter(row['task'] for row in selected) == {
        'hover': 21, 'analytic_circle': 34, 'analytic_figure8': 34, 'analytic_spiral': 35}
    values = []
    with zipfile.ZipFile(root / 'data/configuration_records.zip') as archive:
        for trial in selected:
            raw = archive.read(trial['trial_id'] + '/report.json')
            assert hashlib.sha256(raw).hexdigest() == trial['report_sha256']
            metrics = {item['name']: item for item in json.loads(raw)['metrics']}
            for metric in HOVER_METRICS if trial['task'] == 'hover' else TRACKING_METRICS:
                item = metrics[metric]
                value = float(item['value'])
                assert item.get('available', True) and math.isfinite(value) and value > 0
                if metric in TRACKING_METRICS:
                    field = 'rmse_m' if metric == TRACKING_METRICS[0] else 'p95_m'
                    assert math.isclose(value, float(trial[field]), rel_tol=1e-12, abs_tol=1e-12)
                values.append(dict(trial_id=trial['trial_id'], task=trial['task'],
                                   controller=trial['controller'], metric=metric, value=value,
                                   report_sha256=trial['report_sha256']))
    groups = []
    for task in ['hover'] + TASKS:
        for controller in CONTROLLERS:
            for metric in HOVER_METRICS if task == 'hover' else TRACKING_METRICS:
                group = [row['value'] for row in values if row['task'] == task
                         and row['controller'] == controller and row['metric'] == metric]
                assert len(group) == (3 if task == 'hover' else 4 if controller == CONTROLLERS[0] and task != TASKS[2] else 5)
                groups.append(dict(task=task, controller=controller, metric=metric,
                                   trials=len(group), median=statistics.median(group)))
    assert len(values) == 248 and len(groups) == 56
    return values, groups


def main():
    values, groups = compute()
    (HERE / 'data/control_tracking_trials.csv').write_text(csv_text(values))
    (HERE / 'data/control_tracking_groups.csv').write_text(csv_text(groups))
    print('Reproduced 248 controller trial metrics and 56 group medians.')


if __name__ == '__main__':
    main()
