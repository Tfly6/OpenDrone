"""Recompute fixed-design uncertainty and paired distributions from frozen records.

Uses only the Python standard library. Never starts SITL or changes raw records.
"""
import collections
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import zipfile

HERE = Path(__file__).resolve().parent
METRICS = {
    'duration_s': 'generated_trajectory_duration',
    'speed_max_m_s': 'speed_max',
    'jerk_rms_m_s3': 'jerk_rms',
    'tracking_rmse_m': 'position_tracking_rmse_3d',
}


def percentile(values, fraction):
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    left = int(index)
    return ordered[left] + (ordered[min(left + 1, len(ordered) - 1)] - ordered[left]) * (index - left)


def csv_text(rows):
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue()


def compute(root=HERE):
    trials = list(csv.DictReader((root / 'data/benchmark/trials.csv').open()))
    quality = list(csv.DictReader((root / 'data/controlled/trial_quality.csv').open()))
    grouped = collections.defaultdict(list)
    for row in quality:
        assert row['odom_geometry_0.5'] in ('True', 'False')
        assert row['world_truth_geometry_0.5'] in ('True', 'False')
        world = 'forest' if 'forest' in row['batch'] else 'cylinders'
        grouped[(world, row['planner'], row['controller'], row['waypoint_count'])].append(row)
    assert len(grouped) == 16 and all(len(rows) == 5 for rows in grouped.values())
    conditions = []
    distribution = [1.0]
    for (world, planner, controller, goals), rows in sorted(grouped.items()):
        rows.sort(key=lambda row: int(row['repetition']))
        assert [int(row['repetition']) for row in rows] == [1, 2, 3, 4, 5]
        events = [row['odom_geometry_0.5'] != row['world_truth_geometry_0.5'] for row in rows]
        count = sum(events)
        conditions.append(dict(world=world, planner=planner, controller=controller,
                               goals=int(goals), trials=5, different_labels=count))
        # Exact empirical-bootstrap distribution: sample five repeats with
        # replacement within each fixed cell, retaining both sources together.
        probability = count / 5
        mass = [math.comb(5, k) * probability**k * (1 - probability)**(5 - k) for k in range(6)]
        updated = [0.0] * (len(distribution) + 5)
        for i, left in enumerate(distribution):
            for j, right in enumerate(mass):
                updated[i + j] += left * right
        distribution = updated
    assert abs(sum(distribution) - 1) < 1e-12
    assert abs(sum(k * p for k, p in enumerate(distribution)) - 5) < 1e-12
    assert abs(sum((k - 5)**2 * p for k, p in enumerate(distribution)) - 3.6) < 1e-12

    def discrete_quantile(fraction):
        cumulative = 0.0
        for count, probability in enumerate(distribution):
            cumulative += probability
            if cumulative >= fraction:
                return count / 80
        raise AssertionError('Invalid probability distribution')

    pairs = collections.defaultdict(dict)
    with zipfile.ZipFile(root / 'data/configuration_records.zip') as archive:
        for row in trials:
            if row['task'] not in ('discrete_circle', 'discrete_figure8') or row['included'] != 'True':
                continue
            record = archive.read(row['trial_id'] + '/report.json')
            assert hashlib.sha256(record).hexdigest() == row['report_sha256'], row['trial_id']
            report = json.loads(record)
            metrics = {item['name']: item for item in report['metrics']}
            values = {}
            for output, name in METRICS.items():
                item = metrics[name]
                assert item.get('available', True) and math.isfinite(item['value']), (row['trial_id'], name)
                values[output] = float(item['value'])
            key = (row['task'], row['controller'], int(row['repetition']))
            assert row['planner'] not in pairs[key]
            pairs[key][row['planner']] = (values, row['trial_id'])
    differences = []
    for (task, controller, repeat), records in sorted(pairs.items()):
        if set(records) != {'mav_trajectory', 'rpg_trajectory'}:
            continue
        mav, mav_id = records['mav_trajectory']
        rpg, rpg_id = records['rpg_trajectory']
        differences.append(dict(task=task, controller=controller, repetition=repeat,
                                mav_trial=mav_id, rpg_trial=rpg_id,
                                **{key: rpg[key] - mav[key] for key in METRICS}))
    assert collections.Counter(row['task'] for row in differences) == {'discrete_circle': 35, 'discrete_figure8': 33}
    summaries = []
    for task in ('discrete_circle', 'discrete_figure8'):
        rows = [row for row in differences if row['task'] == task]
        for metric in METRICS:
            values = [row[metric] for row in rows]
            summaries.append(dict(task=task, metric=metric, pairs=len(values),
                                  median=statistics.median(values), q1=percentile(values, .25),
                                  q3=percentile(values, .75), minimum=min(values), maximum=max(values),
                                  positive=sum(value > 0 for value in values), negative=sum(value < 0 for value in values)))
    sparse = [row for row in trials if row['state_samples'] == '3636' and row['rmse_samples'] == '350']
    assert len(sparse) == 1
    sparse = sparse[0]
    total = sum(row['different_labels'] for row in conditions)
    assert total == 5
    dynamic = [row for row in trials if row['world'] == 'cylinders_dynamic_40_30'
               and row['task'] in ('sequential_goal_mission', 'reference_path_mission')]
    summary = dict(
        controlled=dict(trials=80, fixed_cells=16, repeats_per_cell=5, differing_labels=total,
                        proportion=total / 80, cells_with_differences=sum(row['different_labels'] > 0 for row in conditions),
                        conditional_bootstrap_95=[discrete_quantile(.025), discrete_quantile(.975)],
                        method='Exact percentile distribution of stratified empirical bootstrap, five paired-source trials resampled within each fixed cell.',
                        assumption='Exchangeable independent repetitions within cells, with no residual dependence between cells; maps, vehicle, stack and cell weights remain fixed. Zero-event cells remain zero under empirical resampling.',
                        scope='Conditional repeat variation in this design; not uncertainty across new maps, vehicles or platforms.'),
        sparse_reference=dict(trial_id=sparse['trial_id'], rmse_m=float(sparse['rmse_m']),
                              supported_samples=int(sparse['rmse_samples']), state_samples=int(sparse['state_samples']),
                              coverage=float(sparse['reference_coverage']), longest_gap_s=float(sparse['max_reference_gap_s']),
                              native_status=sparse['native_status'], geometry_1m=sparse['geometry_1.0'],
                              passes_coverage_0_9=float(sparse['reference_coverage']) >= .9),
        dynamic_package=dict(trials=len(dynamic), native_success=sum(row['native_status'] == 'succeeded' for row in dynamic),
                             with_contact=sum(float(row['runtime_contact_count']) > 0 for row in dynamic),
                             at_least_five_contacts=sum(float(row['runtime_contact_count']) >= 5 for row in dynamic)),
        input_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in (
            'data/benchmark/trials.csv', 'data/controlled/trial_quality.csv', 'data/configuration_records.zip')})
    return summary, conditions, differences, summaries


def main():
    summary, conditions, differences, summaries = compute()
    (HERE / 'data/paired_trial_statistics.json').write_text(json.dumps(summary, indent=2) + '\n')
    for name, rows in [('controlled_condition_counts', conditions), ('generator_pair_differences', differences), ('generator_pair_summary', summaries)]:
        (HERE / 'data' / (name + '.csv')).write_text(csv_text(rows))
    print(json.dumps(summary['controlled'], indent=2))
    for row in summaries:
        print(row)


if __name__ == '__main__':
    main()
