"""Reproduce the main-text coverage sensitivity example from frozen trial records."""
import csv
import hashlib
import json
from pathlib import Path
from statistics import median
from analyze_paired_trials import csv_text

HERE = Path(__file__).resolve().parent


def compute(root=HERE):
    path = root/'data/benchmark/trials.csv'
    trials = list(csv.DictReader(path.open()))
    saved = list(csv.DictReader((root/'data/benchmark/coverage_sensitivity.csv').open()))
    output = []
    for planner in ('mav_trajectory', 'rpg_trajectory'):
        group = [r for r in trials if r['included']=='True' and r['task']=='discrete_circle'
                 and r['controller']=='lqr_controller' and r['planner']==planner]
        assert len(group)==5
        for threshold in (0., .90, .95):
            selected = [r for r in group if float(r['reference_coverage'])>=threshold]
            errors = [float(r['rmse_m']) for r in selected]
            estimate = median(errors) if errors else None
            original, = [r for r in saved if r['task']=='discrete_circle' and r['controller']=='lqr_controller'
                         and r['planner']==planner and float(r['coverage_threshold'])==threshold]
            assert len(selected)==int(original['retained_trials'])
            assert (not errors and not original['median_rmse_m']) or abs(estimate-float(original['median_rmse_m']))<1e-12
            output.append(dict(task='discrete_circle',controller='lqr_controller',planner=planner,
                               coverage_threshold=threshold,original_trials=5,retained_trials=len(selected),
                               median_rmse_m=estimate))
    summary = dict(input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                   window='Archived controller-phase; may include stopping',
                   aggregation='Median per-trial RMSE after individual-trial coverage selection; descriptive group medians, not paired differences',
                   policy='0.90 and 0.95 are illustrative reporting thresholds used for sensitivity analysis, not calibrated physical success criteria',
                   observed_order='MAV median below RPG in full sample and at 0.90; RPG has no retained trial at 0.95, so no two-pipeline ordering is defined')
    return summary, output


def table(rows):
    header = r'''\papertable{\lang{LQR 圆轨迹的覆盖率门槛敏感性分析：各列为保留试次数 $n$ 与逐试次 RMSE 的中位数（m）；使用归档控制器阶段覆盖率，破折号表示无保留试次}{Coverage-threshold sensitivity for LQR circle tracking: retained trials $n$ and median per-trial RMSE (m), using archived controller-phase coverage; a dash denotes no retained trial}\label{tab:trackingselection}}
{\begin{tabular}{lrrrrrr}\toprule
 & \multicolumn{2}{c}{\lang{完整样本}{Full sample}} & \multicolumn{2}{c}{$\geq .90$} & \multicolumn{2}{c}{$\geq .95$}\\
\lang{流水线}{Pipeline} & $n$ & RMSE & $n$ & RMSE & $n$ & RMSE\\\midrule
'''
    lines=[]
    for planner,label in [('mav_trajectory','MAV'),('rpg_trajectory','RPG')]:
        group=[r for r in rows if r['planner']==planner]
        fields=[]
        for r in group:
            fields += [str(r['retained_trials']), f"{r['median_rmse_m']:.4f}" if r['median_rmse_m'] is not None else '---']
        lines.append(label+' & '+' & '.join(fields)+r'\\')
    return header+'\n'.join(lines)+'\n'+r'\bottomrule\end{tabular}}'+'\n'


def main():
    summary,rows=compute()
    (HERE/'data/tracking_selection_example.csv').write_text(csv_text(rows))
    (HERE/'data/tracking_selection_statistics.json').write_text(json.dumps(summary,indent=2)+'\n')
    if (HERE/'tables').is_dir():
        (HERE/'tables/tracking_selection.tex').write_text(table(rows))
    print('Verified LQR circle: 5/5 -> 5/1 -> 5/0 retained MAV/RPG trials; ordering unchanged where both medians exist.')


if __name__=='__main__':
    main()
